package com.unibuc.ex1curs12.model;

public enum DestinationType {
	SEASIDE, MOUNTAINS, COUNTRYSIDE, CITY
}

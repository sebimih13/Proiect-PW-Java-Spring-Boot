package repository;

public interface DbConnection {
    void connect();
}

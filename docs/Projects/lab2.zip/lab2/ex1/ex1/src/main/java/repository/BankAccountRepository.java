package repository;

import org.springframework.stereotype.Component;

@Component
public class BankAccountRepository {
}

package com.unibuc.ex1curs10.model;

public enum BankAccountType {
    DEBIT, SAVINGS
}

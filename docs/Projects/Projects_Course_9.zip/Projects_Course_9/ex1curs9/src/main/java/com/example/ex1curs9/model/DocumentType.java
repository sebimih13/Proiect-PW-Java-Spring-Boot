package com.example.ex1curs9.model;

public enum DocumentType {
    NATIONAL, INTERNATIONAL
}

package com.unibuc.ex1curs8.repository;

import com.unibuc.ex1curs8.model.BankAccount;
import com.unibuc.ex1curs8.model.BankAccountType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class BankAccountRepository {

    private JdbcTemplate jdbcTemplate;

    public BankAccountRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public BankAccount createBankAccount(BankAccount bankAccount) {
        PreparedStatementCreator insertPsc = connection -> {
            // enhance the PreparedStatement with the RETURN_GENERATED_KEYS feature, so we can get the PK values generated on the db side
            PreparedStatement preparedStatement = connection
                    .prepareStatement("insert into bankaccounts values (?, ?, ?, ?, ?)",
                            Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, null);
            preparedStatement.setString(2, bankAccount.getAccountNumber());
            preparedStatement.setDouble(3, bankAccount.getBalance());
            preparedStatement.setString(4, bankAccount.getType().toString());
            preparedStatement.setString(5, bankAccount.getCardNumber());
            return preparedStatement;
        };
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(insertPsc, keyHolder);

        // we want to return the created bank account on the response body of the endpoint
        return findById(keyHolder.getKey().longValue()).get();
    }

    public Optional<BankAccount> findById(long bankAccountId) {
        PreparedStatementCreator findByIdPsc = connection -> {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("select * from bankaccounts where id = ?");
            preparedStatement.setLong(1, bankAccountId);
            return preparedStatement;
        };
        List<BankAccount> bankAccounts = jdbcTemplate.query(findByIdPsc, getBankAccountRowMapper());
        if(bankAccounts.isEmpty()) {
            return Optional.empty();
        } else {
            return Optional.of(bankAccounts.get(0));
        }
    }

    private RowMapper<BankAccount> getBankAccountRowMapper() {
        RowMapper<BankAccount> mapper = (resultSet, rowNum) ->
             new BankAccount(resultSet.getLong("id"),
                    resultSet.getString("accountNumber"),
                    resultSet.getDouble("balance"),
                    BankAccountType.valueOf(resultSet.getString("type")),
                    resultSet.getString("cardNumber"));
        return mapper;
    }
}

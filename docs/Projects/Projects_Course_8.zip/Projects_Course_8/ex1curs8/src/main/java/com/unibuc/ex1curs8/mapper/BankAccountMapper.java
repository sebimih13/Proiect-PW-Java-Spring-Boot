package com.unibuc.ex1curs8.mapper;

import com.unibuc.ex1curs8.dto.BankAccountRequest;
import com.unibuc.ex1curs8.model.BankAccount;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface BankAccountMapper {

    BankAccount toBankAccount(BankAccountRequest bankAccountRequest);

}

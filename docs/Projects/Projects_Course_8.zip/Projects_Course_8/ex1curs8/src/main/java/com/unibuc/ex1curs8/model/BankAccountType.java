package com.unibuc.ex1curs8.model;

public enum BankAccountType {
    DEBIT, SAVINGS
}

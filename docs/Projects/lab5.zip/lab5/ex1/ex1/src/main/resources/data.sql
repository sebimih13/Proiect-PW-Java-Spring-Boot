INSERT INTO `web2024`.`bankaccount`
(`accountOwner`,
 `balance`,
 `currency`,
 `accountNumber`)
VALUES
       ( "cB1",
        1000.0,
        "RON",
        "0005050001");

INSERT INTO `web2024`.`bankaccount`
(`accountOwner`,
 `balance`,
 `currency`,
 `accountNumber`)
VALUES
    ("cB2",
    1000.0,
    "RON",
    "0005050002");

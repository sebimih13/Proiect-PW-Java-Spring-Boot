package org.example.ex1.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BankAccountRepository {
}

package com.unibuc.ex1curs11.model;

public enum DestinationType {
	SEASIDE, MOUNTAINS, COUNTRYSIDE, CITY
}

package com.unibuc.ex1curs11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1curs11Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex1curs11Application.class, args);
    }

}

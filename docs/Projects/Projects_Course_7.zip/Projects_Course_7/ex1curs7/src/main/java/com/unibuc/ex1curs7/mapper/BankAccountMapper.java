package com.unibuc.ex1curs7.mapper;

import com.unibuc.ex1curs7.dto.BankAccountRequest;
import com.unibuc.ex1curs7.model.BankAccount;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BankAccountMapper {

//    public BankAccount bankAccountRequestToBankAccount(BankAccountRequest bankAccountRequest) {
//        return new BankAccount(bankAccountRequest.getAccountNumber(), bankAccountRequest.getBalance(),
//                bankAccountRequest.getType(), bankAccountRequest.getCardNumber());
//    }

//    @Mapping(source = "x", target = "y") - if the fields name don't match, we need to define a custom mapping
//    @Mapping(target = "id", expression = "java(generateId())")
    BankAccount toBankAccount(BankAccountRequest bankAccountRequest);

}

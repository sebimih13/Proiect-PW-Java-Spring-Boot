package com.unibuc.ex1curs7.exception;

public class CustomerNotFoundException extends NotFoundException {
}

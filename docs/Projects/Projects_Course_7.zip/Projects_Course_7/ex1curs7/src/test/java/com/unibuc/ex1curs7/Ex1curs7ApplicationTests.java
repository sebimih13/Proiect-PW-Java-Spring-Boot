package com.unibuc.ex1curs7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1curs7ApplicationTests {

    @Test
    void contextLoads() {
    }

}
